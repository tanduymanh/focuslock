# FocusLock
Khóa ứng dụng cho bé: nhập 3 bài tập để dùng 30 phút, hết giờ tự thoát.
Phụ huynh mở app bằng mật khẩu để chọn ứng dụng cần khóa và xem lịch sử bài tập.

## Build APK
- Android Studio: mở thư mục, Build > Build APK(s).
- Hoặc đẩy lên GitHub: tab Actions > Build APK > tải artifact FocusLock-apk.
