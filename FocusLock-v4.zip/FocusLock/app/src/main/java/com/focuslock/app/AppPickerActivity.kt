package com.focuslock.app

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.os.Bundle
import android.text.InputType
import android.widget.*

class AppPickerActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pm = packageManager
        val launcher = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(launcher, 0)
            .map { it.activityInfo.packageName to it.loadLabel(pm).toString() }
            .filter { it.first != packageName }
            .distinctBy { it.first }
            .sortedBy { it.second.lowercase() }

        val checked = Store.blocked(this).toMutableSet()

        fun labelFor(i: Int) = "${apps[i].second}  •  ${Store.minutes(this, apps[i].first)} phút"

        val items = apps.indices.map { labelFor(it) }.toMutableList()
        val adapter = ArrayAdapter(
            this, android.R.layout.simple_list_item_multiple_choice, items
        )
        val lv = ListView(this).apply {
            choiceMode = ListView.CHOICE_MODE_MULTIPLE
            this.adapter = adapter
        }
        fun applyChecks() = apps.forEachIndexed { i, a -> lv.setItemChecked(i, a.first in checked) }
        applyChecks()

        lv.setOnItemClickListener { _, _, pos, _ ->
            val pkg = apps[pos].first
            if (lv.isItemChecked(pos)) checked.add(pkg) else checked.remove(pkg)
            Store.setBlocked(this, checked)
        }

        // Giữ lâu để chỉnh số phút cho app đó
        lv.setOnItemLongClickListener { _, _, pos, _ ->
            val pkg = apps[pos].first
            val et = EditText(this).apply {
                inputType = InputType.TYPE_CLASS_NUMBER
                setText(Store.minutes(this@AppPickerActivity, pkg).toString())
                setSelection(text.length)
            }
            AlertDialog.Builder(this)
                .setTitle("Số phút được dùng: ${apps[pos].second}")
                .setView(et)
                .setPositiveButton("Lưu") { _, _ ->
                    val m = et.text.toString().toIntOrNull()
                    if (m != null && m in 1..600) {
                        Store.setMinutes(this, pkg, m)
                        items[pos] = labelFor(pos)
                        adapter.notifyDataSetChanged()
                        applyChecks()
                    } else {
                        Toast.makeText(this, "Nhập từ 1 đến 600 phút", Toast.LENGTH_SHORT).show()
                    }
                }
                .setNegativeButton("Hủy", null)
                .show()
            true
        }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 96, 32, 32)
        }
        root.addView(TextView(this).apply {
            text = "Chọn ứng dụng cần khóa"
            textSize = 22f
            setPadding(16, 0, 0, 8)
        })
        root.addView(TextView(this).apply {
            text = "Chạm để bật/tắt khóa. Giữ lâu một ứng dụng để chỉnh số phút được dùng (mặc định 30)."
            setPadding(16, 0, 16, 16)
        })
        root.addView(lv, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f
        ))
        setContentView(root)
    }
}
