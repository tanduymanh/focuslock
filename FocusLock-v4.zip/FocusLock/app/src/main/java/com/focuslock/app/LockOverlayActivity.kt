package com.focuslock.app

import android.app.Activity
import android.content.ContentValues
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.*

class LockOverlayActivity : Activity() {

    private var appLabel = ""
    private var pkg = ""
    private var pendingUri: Uri? = null
    private val photos = ArrayList<String>()

    private lateinit var info: TextView
    private lateinit var photoInfo: TextView
    private lateinit var ok: Button
    private lateinit var fields: List<EditText>

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun labelOf(p: String?): String {
        if (p == null) return ""
        return try {
            packageManager.getApplicationLabel(packageManager.getApplicationInfo(p, 0)).toString()
        } catch (e: Exception) {
            p
        }
    }

    private fun infoText() =
        "Gõ 3 bài tập bạn vừa làm (hoặc chụp ảnh bài làm), sau đó được dùng $appLabel ${Store.minutes(this, pkg)} phút."

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        pkg = intent.getStringExtra("pkg") ?: ""
        appLabel = labelOf(pkg)
        info.text = infoText()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)

        savedInstanceState?.let {
            photos.addAll(it.getStringArrayList("photos") ?: arrayListOf())
            pendingUri = it.getString("pending")?.let(Uri::parse)
        }
        pkg = intent.getStringExtra("pkg") ?: ""
        appLabel = labelOf(pkg)

        // Nền: ảnh "5 điều Bác Hồ dạy"
        val bg = ImageView(this).apply {
            setImageResource(R.drawable.bg_5dieu)
            scaleType = ImageView.ScaleType.CENTER_CROP
        }

        // Khung nhập nằm phía trên, bán trong suốt để vẫn thấy ảnh nền
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(14), dp(16), dp(14))
            background = GradientDrawable().apply {
                setColor(Color.argb(225, 255, 255, 255))
                cornerRadius = dp(16).toFloat()
            }
        }
        panel.addView(TextView(this).apply {
            text = "Làm 3 bài tập trước khi dùng ứng dụng"
            textSize = 20f
            setTypeface(null, Typeface.BOLD)
            setTextColor(Color.parseColor("#B71C1C"))
        })
        info = TextView(this).apply {
            text = infoText()
            textSize = 14f
            setTextColor(Color.parseColor("#333333"))
            setPadding(0, dp(6), 0, dp(6))
        }
        panel.addView(info)

        fields = (1..3).map { i ->
            EditText(this).apply {
                hint = "Bài tập $i"
                setSingleLine()
                textSize = 16f
            }.also { panel.addView(it) }
        }

        panel.addView(Button(this).apply {
            text = "📷 Hoặc chụp ảnh 3 bài tập"
            setOnClickListener { capture() }
        })
        photoInfo = TextView(this).apply {
            textSize = 14f
            setTextColor(Color.parseColor("#1B5E20"))
        }
        panel.addView(photoInfo)

        ok = Button(this).apply {
            text = "Xác nhận"
            isEnabled = false
        }
        panel.addView(ok)

        val watcher = object : TextWatcher {
            override fun afterTextChanged(s: Editable?) = refresh()
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
        }
        fields.forEach { it.addTextChangedListener(watcher) }

        ok.setOnClickListener {
            val t = fields.map { it.text.toString().trim() }
            Store.addHistory(this, appLabel, t[0], t[1], t[2], photos)
            TimerManager.startUnlock(this, pkg)
            finish()
        }

        val frame = FrameLayout(this)
        frame.addView(bg, FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT
        ))
        frame.addView(
            ScrollView(this).apply { addView(panel) },
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.TOP
            ).apply { setMargins(dp(12), dp(12), dp(12), dp(12)) }
        )
        setContentView(frame)
        refresh()
    }

    private fun refresh() {
        ok.isEnabled = fields.all { it.text.toString().trim().length >= 3 } || photos.isNotEmpty()
        photoInfo.text = if (photos.isEmpty()) "" else "Đã chụp ${photos.size} ảnh ✅"
    }

    private fun capture() {
        try {
            val values = ContentValues().apply {
                put(MediaStore.Images.Media.DISPLAY_NAME, "fl_${System.currentTimeMillis()}.jpg")
                put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
                put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/FocusLock")
            }
            val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
            if (uri == null) {
                Toast.makeText(this, "Không mở được camera", Toast.LENGTH_SHORT).show()
                return
            }
            pendingUri = uri
            val i = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
                .putExtra(MediaStore.EXTRA_OUTPUT, uri)
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
            startActivityForResult(i, 11)
        } catch (e: Exception) {
            Toast.makeText(this, "Không mở được camera", Toast.LENGTH_SHORT).show()
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != 11) return
        val u = pendingUri ?: return
        pendingUri = null
        if (resultCode == RESULT_OK) {
            val name = "${System.currentTimeMillis()}.jpg"
            val f = Store.photoFile(this, name)
            f.parentFile?.mkdirs()
            if (Img.saveScaled(this, u, f)) {
                photos.add(name)
            } else {
                Toast.makeText(this, "Lưu ảnh không được, thử chụp lại", Toast.LENGTH_SHORT).show()
            }
        }
        // Xóa bản gốc trong thư viện ảnh, chỉ giữ bản trong app
        try { contentResolver.delete(u, null, null) } catch (e: Exception) {}
        refresh()
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putStringArrayList("photos", photos)
        outState.putString("pending", pendingUri?.toString())
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        photos.forEach { Store.photoFile(this, it).delete() }
        startActivity(
            Intent(Intent.ACTION_MAIN)
                .addCategory(Intent.CATEGORY_HOME)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        )
        finish()
    }
}
