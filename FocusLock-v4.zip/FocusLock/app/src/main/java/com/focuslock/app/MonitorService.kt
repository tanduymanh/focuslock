package com.focuslock.app

import android.app.*
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.*
import android.provider.Settings

class MonitorService : Service() {

    private val handler = Handler(Looper.getMainLooper())
    private var lastPkg: String? = null
    private var lastLaunch = 0L
    private val unlockedPkgs = mutableSetOf<String>()

    private val tick = object : Runnable {
        override fun run() {
            check()
            handler.postDelayed(this, 1000)
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("monitor", "FocusLock", NotificationManager.IMPORTANCE_LOW)
        )
        val n = Notification.Builder(this, "monitor")
            .setContentTitle("FocusLock đang bảo vệ")
            .setSmallIcon(android.R.drawable.ic_lock_idle_lock)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(1, n)
        }
        handler.removeCallbacks(tick)
        handler.post(tick)
        return START_STICKY
    }

    private fun check() {
        val usm = getSystemService(UsageStatsManager::class.java)
        val now = System.currentTimeMillis()
        val events = usm.queryEvents(now - 10_000, now)
        val e = UsageEvents.Event()
        while (events.hasNextEvent()) {
            events.getNextEvent(e)
            if (e.eventType == UsageEvents.Event.ACTIVITY_RESUMED) lastPkg = e.packageName
        }

        val blocked = Store.blocked(this)

        // Ghi nhận các app đang trong thời gian được dùng
        blocked.forEach { if (TimerManager.isUnlocked(this, it)) unlockedPkgs.add(it) }

        // App nào hết giờ riêng của nó thì thoát và tắt app đó
        val expired = unlockedPkgs.filter { !TimerManager.isUnlocked(this, it) }
        if (expired.isNotEmpty()) {
            expired.forEach { exitApp(it) }
            unlockedPkgs.removeAll(expired.toSet())
            return
        }

        val pkg = lastPkg ?: return
        if (pkg in blocked &&
            !TimerManager.isUnlocked(this, pkg) &&
            Settings.canDrawOverlays(this) &&
            now - lastLaunch > 2500
        ) {
            lastLaunch = now
            startActivity(
                Intent(this, LockOverlayActivity::class.java)
                    .putExtra("pkg", pkg)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        }
    }

    private fun exitApp(pkg: String) {
        if (lastPkg == pkg) {
            startActivity(
                Intent(Intent.ACTION_MAIN)
                    .addCategory(Intent.CATEGORY_HOME)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
            lastPkg = null
        }
        handler.postDelayed({
            getSystemService(ActivityManager::class.java).killBackgroundProcesses(pkg)
        }, 1000)
    }

    override fun onDestroy() {
        handler.removeCallbacks(tick)
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
