package com.focuslock.app

import android.app.Activity
import android.content.Intent
import android.graphics.Typeface
import android.os.Bundle
import android.widget.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class HistoryActivity : Activity() {

    private lateinit var list: LinearLayout

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 96, 48, 48)
        }
        root.addView(TextView(this).apply {
            text = "Lịch sử bài tập của bé"
            textSize = 22f
            setPadding(0, 0, 0, 16)
        })
        root.addView(Button(this).apply {
            text = "Xóa toàn bộ lịch sử"
            setOnClickListener {
                Store.clearHistory(this@HistoryActivity)
                render()
            }
        })
        root.addView(ScrollView(this).apply { addView(list) })
        setContentView(root)
        render()
    }

    private fun render() {
        list.removeAllViews()
        val h = Store.history(this)
        if (h.length() == 0) {
            list.addView(TextView(this).apply { text = "Chưa có lịch sử." })
            return
        }
        val fmt = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale("vi"))
        for (i in h.length() - 1 downTo 0) {
            val o = h.getJSONObject(i)

            list.addView(TextView(this).apply {
                text = "${fmt.format(Date(o.getLong("t")))} - ${o.optString("app")}"
                textSize = 16f
                setTypeface(null, Typeface.BOLD)
                setPadding(0, dp(14), 0, dp(2))
            })

            val e = o.getJSONArray("e")
            val lines = (0 until e.length())
                .filter { e.getString(it).isNotBlank() }
                .map { "${it + 1}. ${e.getString(it)}" }
            if (lines.isNotEmpty()) {
                list.addView(TextView(this).apply {
                    text = lines.joinToString("\n")
                    textSize = 15f
                })
            }

            val p = o.optJSONArray("p")
            if (p != null && p.length() > 0) {
                val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
                for (k in 0 until p.length()) {
                    val name = p.getString(k)
                    val file = Store.photoFile(this, name)
                    row.addView(
                        ImageView(this).apply {
                            scaleType = ImageView.ScaleType.CENTER_CROP
                            if (file.exists()) setImageBitmap(Img.decode(file.path, 300))
                            setOnClickListener {
                                startActivity(
                                    Intent(this@HistoryActivity, PhotoActivity::class.java)
                                        .putExtra("file", name)
                                )
                            }
                        },
                        LinearLayout.LayoutParams(dp(110), dp(110)).apply { rightMargin = dp(8) }
                    )
                }
                list.addView(
                    HorizontalScrollView(this).apply { addView(row) },
                    LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT
                    ).apply { topMargin = dp(6) }
                )
            }
        }
    }
}
