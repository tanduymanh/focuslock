package com.focuslock.app

import android.app.Activity
import android.graphics.Color
import android.os.Bundle
import android.widget.ImageView

class PhotoActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val name = intent.getStringExtra("file") ?: return finish()
        val iv = ImageView(this).apply {
            setBackgroundColor(Color.BLACK)
            scaleType = ImageView.ScaleType.FIT_CENTER
            setImageBitmap(Img.decode(Store.photoFile(this@PhotoActivity, name).path, 1600))
            setOnClickListener { finish() }
        }
        setContentView(iv)
    }
}
