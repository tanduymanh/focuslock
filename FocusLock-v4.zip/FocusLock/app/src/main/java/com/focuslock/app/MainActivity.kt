package com.focuslock.app

import android.Manifest
import android.app.Activity
import android.app.AppOpsManager
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Process
import android.provider.Settings
import android.text.InputType
import android.view.View
import android.widget.*

class MainActivity : Activity() {

    private var status: TextView? = null
    private var authed = false
    private var stopTime = 0L

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Store.hasPassword(this)) showLogin() else showSetup(false)
    }

    override fun onStop() {
        super.onStop()
        stopTime = System.currentTimeMillis()
    }

    override fun onStart() {
        super.onStart()
        // Quay lại sau hơn 2 phút thì phải nhập lại mật khẩu
        if (authed && stopTime > 0 && System.currentTimeMillis() - stopTime > 120_000) {
            authed = false
            showLogin()
        }
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun page(vararg views: View) {
        status = null
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 96, 48, 48)
        }
        views.forEach { root.addView(it) }
        setContentView(ScrollView(this).apply { addView(root) })
    }

    private fun title(t: String) = TextView(this).apply {
        text = t
        textSize = 26f
        setPadding(0, 0, 0, 24)
    }

    private fun btn(t: String, action: () -> Unit) = Button(this).apply {
        text = t
        setOnClickListener { action() }
    }

    private fun pwField(h: String) = EditText(this).apply {
        this.hint = h
        inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
    }

    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_SHORT).show()

    private fun showSetup(changing: Boolean) {
        val f = pwField("Mật khẩu (ít nhất 4 ký tự)")
        page(
            title(if (changing) "Đổi mật khẩu phụ huynh" else "Tạo mật khẩu phụ huynh"),
            f,
            btn("Lưu") {
                val s = f.text.toString()
                if (s.length < 4) {
                    toast("Mật khẩu quá ngắn")
                } else {
                    Store.setPassword(this, s)
                    authed = true
                    showDashboard()
                }
            }
        )
    }

    private fun showLogin() {
        val f = pwField("Mật khẩu phụ huynh")
        page(
            title("FocusLock"),
            f,
            btn("Mở") {
                if (Store.checkPassword(this, f.text.toString())) {
                    authed = true
                    showDashboard()
                } else {
                    toast("Sai mật khẩu")
                }
            }
        )
    }

    private fun showDashboard() {
        val s = TextView(this).apply {
            textSize = 16f
            setPadding(0, 0, 0, 24)
        }
        page(
            title("FocusLock"),
            s,
            btn("1. Cấp quyền Usage Access") {
                startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
            },
            btn("2. Cấp quyền hiển thị trên ứng dụng khác") {
                startActivity(
                    Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
                )
            },
            btn("3. Bật bảo vệ") { startProtection() },
            btn("Chọn ứng dụng cần khóa") {
                startActivity(Intent(this, AppPickerActivity::class.java))
            },
            btn("Xem lịch sử bài tập của bé") {
                startActivity(Intent(this, HistoryActivity::class.java))
            },
            btn("Đổi mật khẩu phụ huynh") { showSetup(true) }
        )
        status = s
        refresh()
    }

    private fun refresh() {
        status?.text = "Usage Access: ${if (hasUsage()) "✅" else "❌"}\n" +
            "Overlay: ${if (Settings.canDrawOverlays(this)) "✅" else "❌"}\n" +
            "Số ứng dụng đang khóa: ${Store.blocked(this).size}"
    }

    private fun hasUsage(): Boolean {
        val ops = getSystemService(AppOpsManager::class.java)
        return ops.unsafeCheckOpNoThrow(
            AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), packageName
        ) == AppOpsManager.MODE_ALLOWED
    }

    private fun startProtection() {
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
        if (!hasUsage() || !Settings.canDrawOverlays(this)) {
            toast("Hãy cấp đủ 2 quyền trước")
            return
        }
        startForegroundService(Intent(this, MonitorService::class.java))
        toast("Đã bật bảo vệ")
    }
}
