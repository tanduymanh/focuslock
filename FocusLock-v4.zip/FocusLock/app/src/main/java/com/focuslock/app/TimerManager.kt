package com.focuslock.app

import android.content.Context

object TimerManager {
    private fun prefs(c: Context) = c.getSharedPreferences("focuslock", Context.MODE_PRIVATE)

    fun startUnlock(c: Context, pkg: String) {
        val until = System.currentTimeMillis() + Store.minutes(c, pkg) * 60_000L
        prefs(c).edit().putLong("until_$pkg", until).apply()
    }

    fun isUnlocked(c: Context, pkg: String) =
        System.currentTimeMillis() < prefs(c).getLong("until_$pkg", 0)
}
