package com.focuslock.app

import android.app.Activity
import android.os.Bundle
import android.widget.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class HistoryActivity : Activity() {

    private lateinit var body: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        body = TextView(this).apply { textSize = 16f }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 96, 48, 48)
        }
        root.addView(TextView(this).apply {
            text = "Lịch sử bài tập của bé"
            textSize = 22f
            setPadding(0, 0, 0, 16)
        })
        root.addView(Button(this).apply {
            text = "Xóa toàn bộ lịch sử"
            setOnClickListener {
                Store.clearHistory(this@HistoryActivity)
                render()
            }
        })
        root.addView(ScrollView(this).apply { addView(body) })
        setContentView(root)
        render()
    }

    private fun render() {
        val h = Store.history(this)
        if (h.length() == 0) {
            body.text = "Chưa có lịch sử."
            return
        }
        val fmt = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale("vi"))
        val sb = StringBuilder()
        for (i in h.length() - 1 downTo 0) {
            val o = h.getJSONObject(i)
            val e = o.getJSONArray("e")
            sb.append(fmt.format(Date(o.getLong("t"))))
                .append(" - ").append(o.optString("app")).append("\n")
            for (k in 0 until e.length()) sb.append("  ${k + 1}. ").append(e.getString(k)).append("\n")
            sb.append("\n")
        }
        body.text = sb.toString()
    }
}
