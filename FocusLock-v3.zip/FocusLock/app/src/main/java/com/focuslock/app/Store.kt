package com.focuslock.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.security.MessageDigest

object Store {
    private fun p(c: Context) = c.getSharedPreferences("focuslock", Context.MODE_PRIVATE)

    private fun hash(s: String): String =
        MessageDigest.getInstance("SHA-256").digest(("fl:$s").toByteArray())
            .joinToString("") { "%02x".format(it) }

    fun hasPassword(c: Context) = p(c).contains("pw")
    fun setPassword(c: Context, pw: String) = p(c).edit().putString("pw", hash(pw)).apply()
    fun checkPassword(c: Context, pw: String) = p(c).getString("pw", null) == hash(pw)

    fun blocked(c: Context): Set<String> =
        (p(c).getStringSet("blocked", setOf("com.google.android.youtube")) ?: emptySet()).toSet()

    fun setBlocked(c: Context, s: Set<String>) =
        p(c).edit().putStringSet("blocked", HashSet(s)).apply()

    fun minutes(c: Context, pkg: String): Int = p(c).getInt("min_$pkg", 30)
    fun setMinutes(c: Context, pkg: String, m: Int) = p(c).edit().putInt("min_$pkg", m).apply()

    fun addHistory(c: Context, app: String, a: String, b: String, d: String) {
        val arr = JSONArray(p(c).getString("hist", "[]"))
        arr.put(JSONObject().apply {
            put("t", System.currentTimeMillis())
            put("app", app)
            put("e", JSONArray(listOf(a, b, d)))
        })
        while (arr.length() > 500) arr.remove(0)
        p(c).edit().putString("hist", arr.toString()).apply()
    }

    fun history(c: Context): JSONArray = JSONArray(p(c).getString("hist", "[]"))
    fun clearHistory(c: Context) = p(c).edit().remove("hist").apply()
}
