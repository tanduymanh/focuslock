package com.focuslock.app

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.widget.*

class LockOverlayActivity : Activity() {

    private var appLabel = ""
    private var pkg = ""
    private lateinit var info: TextView

    private fun labelOf(pkg: String?): String {
        if (pkg == null) return ""
        return try {
            packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString()
        } catch (e: Exception) {
            pkg
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        pkg = intent.getStringExtra("pkg") ?: ""
        appLabel = labelOf(pkg)
        info.text = infoText()
    }

    private fun infoText() =
        "Nhập 3 bài tập bạn vừa làm, sau đó được dùng $appLabel ${Store.minutes(this, pkg)} phút."

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        pkg = intent.getStringExtra("pkg") ?: ""
        appLabel = labelOf(pkg)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(64, 64, 64, 64)
            setBackgroundColor(Color.WHITE)
        }
        root.addView(TextView(this).apply {
            text = "Làm 3 bài tập trước khi dùng ứng dụng"
            textSize = 24f
            gravity = Gravity.CENTER
        })
        info = TextView(this).apply {
            text = infoText()
            gravity = Gravity.CENTER
            setPadding(0, 16, 0, 32)
        }
        root.addView(info)

        val fields = (1..3).map { i ->
            EditText(this).apply { hint = "Bài tập $i" }.also { root.addView(it) }
        }
        val ok = Button(this).apply {
            text = "Xác nhận"
            isEnabled = false
        }
        root.addView(ok)

        val watcher = object : TextWatcher {
            override fun afterTextChanged(s: Editable?) {
                ok.isEnabled = fields.all { it.text.toString().trim().length >= 3 }
            }
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
        }
        fields.forEach { it.addTextChangedListener(watcher) }

        ok.setOnClickListener {
            val t = fields.map { it.text.toString().trim() }
            Store.addHistory(this, appLabel, t[0], t[1], t[2])
            TimerManager.startUnlock(this, pkg)
            finish()
        }
        setContentView(root)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        startActivity(
            Intent(Intent.ACTION_MAIN)
                .addCategory(Intent.CATEGORY_HOME)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        )
        finish()
    }
}
